package bhp.groupon;

import bhp.groupon.Services.CompanyServiceImpl;
import bhp.groupon.beans.Constants;
import bhp.groupon.security.ClientType;
import bhp.groupon.security.LoginManager;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.FilterType;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootTest
//
//@SpringBootApplication
//@ComponentScan(basePackages = { "bhp.groupon" }, excludeFilters = @ComponentScan.Filter(type = FilterType.ASPECTJ, pattern = "bhp.groupon.clr.off.*"))
//@EnableScheduling


class GrouponApplicationTests {

	@Test
	void contextLoads() throws Exception {
//		LoginManager loginManager = LoginManager.getInstance();
//		System.out.println("Constants.NIKE_EMAIL.getValue()=" + Constants.NIKE_EMAIL.getValue() );
//		CompanyServiceImpl companyServiceImpl = (CompanyServiceImpl) loginManager.login(Constants.NIKE_EMAIL.getValue(),Constants.NIKE_PASSWORD.getValue(), ClientType.COMPANY);


	}

}
