package bhp.groupon.exceptions;

public class CouponSystemException extends Exception{
    public CouponSystemException(ErrMsg errMsg){
        super(errMsg.getMsg());
    }
}
