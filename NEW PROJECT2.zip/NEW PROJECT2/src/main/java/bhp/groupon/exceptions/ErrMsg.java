package bhp.groupon.exceptions;

import lombok.Getter;

@Getter
public enum ErrMsg {
    ID_NOT_FOUND("Id not found...."),
    ID_ALREADY_EXIST("Id already exist....."),
    EMAIL_ALREADY_EXIST("Email already exist....."),
    PASSWORD_ALREADY_EXIST("Password already exist....."),
    NAME_ALREADY_EXIST("Name already exist....."),
    ADMIN_NOT_AUTHORIZED("Admin not authorized"),
    NOT_AUTHORIZED("LoginManager : You are not authorized to use this service ..."),
    CUSTOMER_NOT_EXIST("Customer not exist...."),
    COUPON_ALREADY_EXIST_BY_TITLE("This coupon already exist by Title...."),
    COUPON_NOT_EXIST_BY_TITLE("This coupon not exist by Title...."),
    COUPON_ALREADY_PURCHASED("You have already ordered this coupon...."),
    COUPON_NOT_IN_STOCK("This coupon is out of stock...."),
    COMPANY_NOT_EXIST("Company not exist....");


    private String msg;

    ErrMsg(String msg) {
        this.msg = msg;
    }
}
