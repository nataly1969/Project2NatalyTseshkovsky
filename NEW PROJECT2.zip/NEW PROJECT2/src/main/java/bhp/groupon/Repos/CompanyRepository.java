package bhp.groupon.Repos;

import bhp.groupon.beans.Company;
import bhp.groupon.beans.Coupon;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.sql.SQLException;
import java.util.List;
@Repository
public interface CompanyRepository extends JpaRepository<Company,Integer> {
    /*---------------------------  exists --------------------------------*/
    boolean existsByEmailAndPassword(String email, String password ) ;
    boolean existsById(int Id) ;
    boolean existsByEmail(String email);
    boolean existsByName(String name);
    /*---------------------------  ONE   -------------------------------*/
    Company findByEmailAndPassword(String email, String password);
    Company findById(int Id) ;

    /*---------------------------   ALL  -------------------------------*/
    List<Company> findAll() ;

}



