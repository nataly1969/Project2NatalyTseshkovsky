package bhp.groupon.Repos;

import bhp.groupon.beans.Category;
import bhp.groupon.beans.Company;
import bhp.groupon.beans.Coupon;
import bhp.groupon.beans.Coupon;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface CouponRepository  extends JpaRepository<Coupon,Integer> {

    /*---------------------------  exists --------------------------------*/
    boolean existsById(int id);
    boolean existsByCompanyIdAndTitle(int companyId,String title);
    @Query(value = "select exists (SELECT * FROM couponsysb.coupons where id = :couponId and amount > 0 and end_date > current_date())",nativeQuery = true)
    int existCouponInStock(@Param("couponId") int couponId);

    /*---------------------------  ONE coupon    --------------------------*/
    Coupon       findByCompanyIdAndTitle(int companyId,String title);
    List<Coupon> findAllByCompanyId(int companyId);

 /*------------------------------  ALL coupons with max price --------------*/
    @Query(value = "SELECT * FROM couponsysb.coupons WHERE company_id = :companyId and price < :price",nativeQuery = true)
    List<Coupon> findCompanyCouponsMaxPrice(@Param("companyId") int companyId,@Param("price") double price);
//  todo List<Coupon> findAllByCompanyIdAndPriceLessThen(int companyId,double price);

    @Query(value = "SELECT * from couponsysb.coupons   where  id in\n" +
            "(select coupons_id  from couponsysb.customers_coupons  where   customer_id = :customerId and price < :price)",nativeQuery = true)
    List<Coupon> findCustomerCouponsMaxPrice(@Param("customerId") int customerId,@Param("price") double price);

    /*-------------------------  ALL coupons by  category   --------------*/
    List<Coupon> findAllByCompanyIdAndCategory(int companyId, Category category);
    @Query(value = "SELECT * from couponsysb.coupons where id in (select coupons_id FROM couponsysb.customers_coupons where customer_id = :customerId)",nativeQuery = true)
    List<Coupon> getAllCouponsByCustomerId(@Param("customerId") int customerId);

     @Query(value = "SELECT * from couponsysb.coupons   where  id in\n" +
             "(select coupons_id  FROM couponsysb.customers_coupons  where   customer_id = :customerId and category = :category);",nativeQuery = true)
    List<Coupon> getAllCustomerCouponsByCategory(@Param("customerId") int customerId, @Param("category") String category);


    /* ---------------------    delete ALL purchased coupons --------------*/
    @Transactional
    @Modifying
     @Query(value = "delete from couponsysb.customers_coupons where coupons_id = :couponsId",nativeQuery = true)
    void deletePurchasesOfCoupon(@Param("couponsId") int couponsId);

    @Transactional
    @Modifying
    @Query(value = "delete FROM couponsysb.customers_coupons a\n" +
        "where a.coupons_id in (SELECT b.id FROM couponsysb.coupons b WHERE b.company_id =:companyId)",nativeQuery = true)
    void deleteAllCompanyCouponsPurchased(@Param("companyId") int companyId);

    /* -----------------      EXPIRED  coupons ---------------------------------*/
    @Query(value = "SELECT * from  couponsysb.coupons WHERE  end_date <= current_date()",nativeQuery = true)
    List<Coupon> getAllCouponsExpiredDate();

    @Transactional
    @Modifying
    @Query(value = "delete from  couponsysb.coupons WHERE  end_date <= current_date()",nativeQuery = true)
    void deleteAllCouponsExpiredDate();

    /*-----------------------------------------------------------------------------*/

}
