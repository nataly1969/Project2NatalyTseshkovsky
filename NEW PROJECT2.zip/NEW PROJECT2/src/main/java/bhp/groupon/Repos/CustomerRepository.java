package bhp.groupon.Repos;
import bhp.groupon.beans.Company;
import bhp.groupon.beans.Coupon;
import bhp.groupon.beans.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface CustomerRepository extends JpaRepository<Customer,Integer> {

    /*---------------------------  exists --------------------------------*/
    boolean existsByEmail(String email);
    boolean existsByEmailAndPassword(String email, String password ) ;
    @Query(value = "select exists(select * from couponsysb.customers_coupons where customer_id = :customerId and coupons_id = :couponId)",nativeQuery = true)
    int existCouponPurchasedByCustomer(@Param("customerId") int customerId ,@Param("couponId") int couponId);

    /*---------------------------  ONE   -------------------------------*/
    Customer findById(int customerId);
    Customer findByEmailAndPassword(String email, String password);
    /*---------------------------   ALL  -------------------------------*/
    @Override
    List<Customer> findAll();
    @Query(value = "SELECT * from couponsysb.customers where id in (select customer_id from couponsysb.customers_coupons where coupons_id = :couponsId)",nativeQuery = true)
    List<Customer> getAllCustomersByCouponId(@Param("couponsId") int couponsId);

    /*---------------------         E N D        Customer Repository  ---------------------------*/
}
