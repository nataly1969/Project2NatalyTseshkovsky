package bhp.groupon.beans;

import lombok.Getter;

@Getter
public enum Constants {

       /*        ADMIN      */
    ADMIN_EMAIL("admin@admin.com"),
    ADMIN_PASSWORD("admin"),

    /*     c o m p a n i e s       */
    COCA_COLA_NAME("CocaCola"),
    COCA_COLA_EMAIL("CocaCola@gmail.com"),
    COCA_COLA_PASSWORD("1234"),

    SUPER_PHARM_NAME("SuperPharm"),
    SUPER_PHARM_EMAIL("SuperPharm@gmail.com"),
    SUPER_PHARM_PASSWORD("1234"),

    NIKE_NAME("Nike"),
    NIKE_EMAIL("Nike@gmail.com"),
    NIKE_PASSWORD("1234"),

    ISROTEL_NAME("Isrotel"),
    ISROTEL_EMAIL("Isrotel@gmail.com"),
    ISROTEL_PASSWORD("1234"),

    MAX_BRENNER_NAME("MaxBrenner"),
    MAX_BRENNER_EMAIL("MaxBrenner@gmail.com"),
    MAX_BRENNER_PASSWORD("1234"),

/*        c u s t o m e r s      */
    CUSTOMER1_EMAIL("artur@gmail.com"), CUSTOMER1_PASSWORD("1234"),
    CUSTOMER2_EMAIL("dinnerov@mail.ru"), CUSTOMER2_PASSWORD("1234"),
    CUSTOMER3_EMAIL("eli@gmail.com"), CUSTOMER3_PASSWORD("1234"),
    CUSTOMER4_EMAIL("geula@gmail.com"), CUSTOMER4_PASSWORD("1234"),
    CUSTOMER5_EMAIL("choklatier@mail.ru"), CUSTOMER5_PASSWORD("1234");


    private String value;

    Constants(String value) {
        this.value = value;
    }
}
