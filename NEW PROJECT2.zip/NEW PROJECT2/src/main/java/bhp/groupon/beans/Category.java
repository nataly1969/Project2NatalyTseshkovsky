package bhp.groupon.beans;

public enum Category {
    Food,
    Medicine,
    Restaurant,
    Vacation,
    Sport

}
