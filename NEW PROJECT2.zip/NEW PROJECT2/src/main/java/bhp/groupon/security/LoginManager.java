package bhp.groupon.security;

import bhp.groupon.Services.AdminService;
import bhp.groupon.Services.ClientService;
import bhp.groupon.Services.CompanyService;
import bhp.groupon.Services.CustomerService;
import bhp.groupon.beans.Constants;
import bhp.groupon.exceptions.CouponSystemException;
import bhp.groupon.exceptions.ErrMsg;
import bhp.groupon.utils.Art;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class LoginManager {
    private final AdminService adminService;
    private final CompanyService companyService;
    private final CustomerService customerService;

    /*-------------------------------------------------------------------------*/
    /*---------------------           l o g i n              -----------------*/
    public ClientService login(String email, String password, ClientType clientType) throws CouponSystemException {
        System.out.println("\n  LOGIN MANAGER STARTED ");

        System.out.println("  LOGIN MANAGER FOR " + clientType + " " + email + " " + password + "\n");
        ClientService service = null;

        switch (clientType) {
            case ADMINISTRATOR: {
                if (email.equals(Constants.ADMIN_EMAIL.getValue()) && password.equals(Constants.ADMIN_PASSWORD.getValue())) {
                    System.out.println(Art.ADMIN_FACADE);
                    service = (ClientService) adminService;
                } else {
                    throw new CouponSystemException(ErrMsg.NOT_AUTHORIZED);
                }
                break;
            }
            case COMPANY:
                service = (ClientService) companyService;
                if (!service.login(email, password)) {
                    service = null;
                    throw new CouponSystemException(ErrMsg.NOT_AUTHORIZED);
                }
                System.out.println(Art.COMPANY);
                break;

            case CUSTOMER:
                service = (ClientService) customerService;
                if (!service.login(email, password)) {
                    service = null;
                    throw new CouponSystemException(ErrMsg.NOT_AUTHORIZED);
                }
                System.out.println(Art.CUSTOMER);
                break;
            default:
                throw new CouponSystemException(ErrMsg.NOT_AUTHORIZED);
        }
        return service;
    }

    /*------------------------------------------------------------------------*/
    /*           c r e a t e         s i n g l e t o n       3 steps:         */
    /*     step1 : create a single ref here                                   */
    /*private LoginManager instance = new LoginManager();
    /*   Step 2 : private CTOR                                                */
    /*private LoginManager(){};
    /*   step3 :  expose static get                                           */
    /*public static LoginManager getInstance() {
        return instance;
    }

    /*    ClientService clientService = new ClientService() {
           @Override
           public boolean login(String email, String password) throws SQLException, InterruptedException {
               return false;
           }
       };
        if (clientType.equals(ClientType.ADMINISTRATOR) && email.equals(Constants.ADMIN_EMAIL) && password.equals(Constants.ADMIN_PASSWORD))
        {   System.out.println(Art.ADMIN_FACADE);
           clientService = new AdminServiceImpl() ;

            return clientService;}
        if (clientType.equals(ClientType.COMPANY)){
            clientService = new CompanyServiceImpl();
        }   clientService.login(email, password);
            System.out.println("login  of Company is OK");

            return clientService;}

        if (clientType.equals(ClientType.CUSTOMER) && customerService.login(email, password)){
            System.out.println("login  of Client is OK");
            return (ClientService) customerService;}

        return null;
    } */

}
