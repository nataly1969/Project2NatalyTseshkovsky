package bhp.groupon.security;

public enum ClientType {
    ADMINISTRATOR,
    COMPANY,
    CUSTOMER;
}
