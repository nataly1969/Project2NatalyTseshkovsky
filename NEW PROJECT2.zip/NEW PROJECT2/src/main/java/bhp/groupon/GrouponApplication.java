package bhp.groupon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.FilterType;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@ComponentScan(basePackages = { "bhp.groupon" }, excludeFilters = @ComponentScan.Filter(type = FilterType.ASPECTJ, pattern = "bhp.groupon.clr.off.*"))
@EnableScheduling

public class GrouponApplication {

	public static void main(String[] args) {

		SpringApplication.run(GrouponApplication.class, args);

	}

}
