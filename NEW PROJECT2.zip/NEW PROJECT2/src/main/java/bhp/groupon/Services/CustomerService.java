package bhp.groupon.Services;
import bhp.groupon.beans.Category;
import bhp.groupon.beans.Coupon;
import bhp.groupon.beans.Customer;
import bhp.groupon.exceptions.CouponSystemException;
import java.sql.SQLException;
import java.util.List;
public interface CustomerService {

    boolean login(String email, String password)                                 throws CouponSystemException;
    /* --------------------------CRUD   Customer------------------------- */
    void         purchaseCoupon(int customerId, Coupon coupon)                   throws CouponSystemException;
    /* --------------------------get ONE -------------------------------- */
    Customer     getCustomersDetails(int customerId)                             throws CouponSystemException;
    Coupon       getOneCompanyCouponByTitle(int companyId , String title)        throws CouponSystemException;
    /* --------------------------get ALL -------------------------------- */
    List<Coupon> getCustomerCoupons(int customerId)                              throws CouponSystemException;
    List<Coupon> getCustomerCouponsByCategory(int customerId, Category category) throws CouponSystemException;
    List<Coupon> getCustomerCouponsMaxPrice(int customerId, double maxPrice)     throws CouponSystemException;

    /* ----------------  e n d      customer   service    ---------------------------------*/
}