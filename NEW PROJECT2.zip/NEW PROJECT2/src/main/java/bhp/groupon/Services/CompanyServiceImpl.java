package bhp.groupon.Services;

import bhp.groupon.Repos.CompanyRepository;
import bhp.groupon.Repos.CouponRepository;
import bhp.groupon.Repos.CustomerRepository;
import bhp.groupon.beans.Category;
import bhp.groupon.beans.Company;
import bhp.groupon.beans.Coupon;
import bhp.groupon.exceptions.CouponSystemException;
import bhp.groupon.exceptions.ErrMsg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;

import javax.persistence.Access;
import java.sql.SQLException;
import java.util.List;

@Service
public class CompanyServiceImpl extends  ClientService implements CompanyService{
    /*   zmani.  (it will be in  ClientFacade only !) */
    @Autowired
    private CompanyRepository companyRepository;
    @Autowired
    private CouponRepository couponRepository;
    @Autowired
    private CustomerRepository customerRepository;

    @Override
    public boolean login(String email, String password) throws CouponSystemException {
       return companyRepository.existsByEmailAndPassword(email, password);
    }
    /* --------------------------get ONE ---------------------------------------------------------*/
    @Override
    public Company getCompanyDetails(int companyId) throws CouponSystemException {
//      return companyRepository.findById(companyId).orElseThrow(()->new CouponSystemException(ErrMsg.COMPANY_NOT_EXIST));
        return companyRepository.findById(companyId);
    }
    @Override
    public Coupon getOneCompanyCouponByTitle(int companyId, String title) throws CouponSystemException {
//     return couponRepository.findByCompanyIdAndTitle(companyId,title).orElseThrow(()->new CouponSystemException(ErrMsg.COUPON_NOT_EXIST_BY_TITLE));
       return couponRepository.findByCompanyIdAndTitle(companyId,title);
    }
    /* --------------------------get ALL --------------------------------------------------------- */
    @Override
    public List<Coupon> getCompanyCoupons(int companyId) throws CouponSystemException {
//     return couponRepository.findAllByCompanyId(companyId).orElseThrow(()->new CouponSystemException(ErrMsg.COUPON_NOT_IN_STOCK));
       return couponRepository.findAllByCompanyId(companyId);
    }
    @Override
    public List<Coupon> getCompanyCouponsByCategory(int companyId, Category category) throws CouponSystemException {
//     return couponRepository.findAllByCompanyIdAndCategory(companyId,category).orElseThrow(()->new CouponSystemException(ErrMsg.COUPON_NOT_IN_STOCK));
       return couponRepository.findAllByCompanyIdAndCategory(companyId,category);
    }
    @Override
    public List<Coupon> getCompanyCouponsUnderPrice(int companyId, double price) throws CouponSystemException {
//     return couponRepository.findCompanyCouponsMaxPrice(companyId,price).orElseThrow(()->new CouponSystemException(ErrMsg.COUPON_NOT_IN_STOCK));
       return couponRepository.findCompanyCouponsMaxPrice(companyId,price);
        }

    /* --------------------------CRUD   COMPANY--------------------------------------------------------- */
       @Override
    public void addCoupon(int companyId, Coupon coupon) throws CouponSystemException {
        if (!companyRepository.existsById(companyId)) {
             throw new CouponSystemException(ErrMsg.COMPANY_NOT_EXIST);
        } else if (couponRepository.existsByCompanyIdAndTitle(companyId, coupon.getTitle())) {
             throw new CouponSystemException(ErrMsg.COUPON_ALREADY_EXIST_BY_TITLE);
        } else {
                Company company = companyRepository.findById(companyId);
                coupon.setCompany(company);
             try {
                couponRepository.save(coupon);
            } catch (Exception e) {
                System.err.println(e.getMessage());
            }
        }
    }

    @Override
    public void updateCoupon(int companyId, Coupon coupon) throws CouponSystemException {
        if (!companyRepository.existsById(companyId)) {
            throw new CouponSystemException(ErrMsg.COMPANY_NOT_EXIST);
        } else if (!couponRepository.existsByCompanyIdAndTitle(companyId, coupon.getTitle())) {
            throw new CouponSystemException(ErrMsg.COUPON_NOT_EXIST_BY_TITLE);
        } else {
            Coupon fetchedCoupon = couponRepository.findByCompanyIdAndTitle(companyId, coupon.getTitle());
            if (fetchedCoupon.getCategory() == coupon.getCategory())
            {    coupon.setTitle(fetchedCoupon.getTitle());
                try {
                    couponRepository.saveAndFlush(coupon);
                    System.out.println("        CompanyFacade.updateCoupon:    new coupon updated successfully! ");
                } catch (Exception e) {
                    System.err.println(e.getMessage());
                }}
            else {
                System.out.println("        CompanyFacade.updateCoupon:  Don't  change Title and Category og coupon");}
        }
   }

    @Override
    public void deleteCoupon(int companyId, int couponId) throws CouponSystemException {
        if (couponRepository.existsById(couponId)) {
            Coupon coupon = couponRepository.getById(couponId);
            if (companyId != coupon.getCompany().getId()) {
                System.out.println("        Companyaservice.deleteCoupon:  company " + companyId + " not autorized to delete coupons of company " + coupon.getCompany().getId());
                return;
            }
        try {
            couponRepository.deletePurchasesOfCoupon(couponId);
            couponRepository.deleteById(couponId);
           }  catch (Exception e) {
                System.err.println(e.getMessage());
            }
        }
    }
    /*=======================   e n d ================================*/
}
