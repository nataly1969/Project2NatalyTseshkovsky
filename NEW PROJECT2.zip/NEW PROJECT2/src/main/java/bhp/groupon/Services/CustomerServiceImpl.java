package bhp.groupon.Services;

import bhp.groupon.Repos.CompanyRepository;
import bhp.groupon.Repos.CouponRepository;
import bhp.groupon.Repos.CustomerRepository;
import bhp.groupon.beans.*;
import bhp.groupon.exceptions.CouponSystemException;
import bhp.groupon.exceptions.ErrMsg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.List;
import java.util.Set;


@Service
public class CustomerServiceImpl extends  ClientService implements CustomerService{
    /*   zmani.  (it will be in  ClientFacade only !) */
    @Autowired
    private CompanyRepository companyRepository;
    @Autowired
    private CouponRepository couponRepository;
    @Autowired
    private CustomerRepository customerRepository;

    public CustomerServiceImpl() {}

    @Override
    public boolean login(String email, String password) throws CouponSystemException {
        return customerRepository.existsByEmailAndPassword(email, password);
    }

    @Override
    public Customer getCustomersDetails(int customerId) throws CouponSystemException {
//      return customerRepository.findById(customerId).orElseThrow(()->new CouponSystemException(ErrMsg.CUSTOMER_NOT_EXIST));
        return customerRepository.findById(customerId);
    }

    /*----------------------- get coupons of customer-----------------------------------------------*/
    @Override
    public List<Coupon> getCustomerCoupons(int customerId) throws CouponSystemException {
         return couponRepository.getAllCouponsByCustomerId(customerId);
    }

    @Override
    public List<Coupon> getCustomerCouponsByCategory(int customerId, Category category) throws CouponSystemException {
        return couponRepository.getAllCustomerCouponsByCategory(customerId, String.valueOf(category));
    }

    @Override
    public List<Coupon> getCustomerCouponsMaxPrice(int customerId, double maxPrice) throws CouponSystemException {
        return couponRepository.findCustomerCouponsMaxPrice(customerId,maxPrice);
    }

    @Override
    public Coupon getOneCompanyCouponByTitle(int companyId, String title) throws CouponSystemException {
        return couponRepository.findByCompanyIdAndTitle(companyId,title);
    }

//    @Override
//    public List<Customer> getAllCustomersByCouponsId(int couponsId) {
//        return  customerRepository.findALLByCouponsId(couponsId);
//    }

    /*----------------------- purchase coupon -----------------------------------------------*/
    @Override
    public void purchaseCoupon(int customerId, Coupon coupon) throws CouponSystemException {
      if (!customerRepository.existsById(customerId)) {
            throw new CouponSystemException(ErrMsg.CUSTOMER_NOT_EXIST);}
      if (customerRepository.existCouponPurchasedByCustomer(customerId, coupon.getId()) > 0 ) {
            throw new CouponSystemException(ErrMsg.COUPON_ALREADY_PURCHASED);}
      if (couponRepository.existCouponInStock(coupon.getId())==0) {
            throw new CouponSystemException(ErrMsg.COUPON_NOT_IN_STOCK);}
                              /* reduce amount of purchased coupon in company's stock*/
      coupon.setAmount(coupon.getAmount()-1 );
      couponRepository.saveAndFlush(coupon);
                              /* add purchased coupon to customer */
      Customer customerUpdated = customerRepository.getById(customerId);
      customerUpdated.getCoupons().add(coupon);
      customerRepository.saveAndFlush(customerUpdated);
    }
}
