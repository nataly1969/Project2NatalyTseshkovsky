package bhp.groupon.Services;

import bhp.groupon.Repos.CompanyRepository;
import bhp.groupon.Repos.CouponRepository;
import bhp.groupon.Repos.CustomerRepository;
import bhp.groupon.exceptions.CouponSystemException;
import org.springframework.beans.factory.annotation.Autowired;

import java.sql.SQLException;

public abstract class ClientService {
    protected CouponRepository   couponRepository;
    protected CompanyRepository  companyRepository;
    protected CustomerRepository customerRepository;

    public abstract boolean login(String email,String password) throws CouponSystemException;
}
