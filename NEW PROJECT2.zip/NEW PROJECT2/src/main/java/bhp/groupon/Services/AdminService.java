package bhp.groupon.Services;

import bhp.groupon.beans.Company;
import bhp.groupon.beans.Customer;
import bhp.groupon.exceptions.CouponSystemException;
import java.util.List;
public interface AdminService {

    /* --------------------------get ONE -------------------------------- */
    Company getOneCompany(int companyId)    throws CouponSystemException;
    Customer getOneCustomer(int customerId) throws CouponSystemException;
    /* --------------------------get ALL -------------------------------- */
    List<Company> getAllCompanies()         throws CouponSystemException;
    List<Customer> getAllCustomers()        throws CouponSystemException;

    /* --------------------------CRUD   COMPANY--------------------------- */
    void addCompany(Company company)        throws CouponSystemException;
    void updateCompany(Company company)     throws CouponSystemException;
    void deleteCompany(Company company)     throws CouponSystemException;

    /*--------------------       CRUD customers ----------------------------*/
    void addCustomer(Customer customer)     throws CouponSystemException;
    void updateCustomer(Customer customer)  throws CouponSystemException;
    void deleteCustomer(Customer customer)  throws CouponSystemException;


}
