package bhp.groupon.Services;

import bhp.groupon.Repos.CompanyRepository;
import bhp.groupon.Repos.CouponRepository;
import bhp.groupon.Repos.CustomerRepository;
import bhp.groupon.beans.Company;
import bhp.groupon.beans.Customer;
import bhp.groupon.exceptions.CouponSystemException;
import bhp.groupon.exceptions.ErrMsg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;


@Service
public class AdminServiceImpl extends ClientService implements AdminService {

    /*   zmani.  (it will be in  ClientFacade only !) */
    @Autowired
    private CompanyRepository companyRepository;
    @Autowired
    private CouponRepository couponRepository;
    @Autowired
    private CustomerRepository customerRepository;

    public AdminServiceImpl() {
    }

    @Override
    public boolean login(String email, String password) throws CouponSystemException {
        return false;
    }
    /* --------------------------get one -------------------------- */
    @Override
    public Company getOneCompany(int companyId) {
//  return companyRepository.findById(companyId).orElseThrow(()->new CouponSystemException(ErrMsg.COMPANY_NOT_EXIST));
    return companyRepository.findById(companyId);
    }

    @Override
    public Customer getOneCustomer(int customerId) {
//  return companyRepository.findById(customerId).orElseThrow(()->new CouponSystemException(ErrMsg.CUSTOMER_NOT_EXIST));
    return customerRepository.findById(customerId);
    }
    /* --------------------------get all -------------------------------- */
    @Override
    public List<Company> getAllCompanies() {
//      return companyRepository.findALL().orElseThrow(()->new CouponSystemException(ErrMsg.COMPANY_NOT_EXIST));
        return companyRepository.findAll();
    }

    @Override
    public List<Customer> getAllCustomers() {
//      return companyRepository.findAll().orElseThrow(()->new CouponSystemException(ErrMsg.CUSTOMER_NOT_EXIST));
        return customerRepository.findAll();
    }

    /* --------------------------CRUD   COMPANY--------------------------- */
    @Override
    public void addCompany(Company company) throws CouponSystemException {
        if (companyRepository.existsByEmail(company.getEmail())) {
            throw new CouponSystemException(ErrMsg.EMAIL_ALREADY_EXIST);
        }
        if (companyRepository.existsByName(company.getName())) {
            throw new CouponSystemException(ErrMsg.NAME_ALREADY_EXIST);
        }
        companyRepository.save(company);
    }

    @Override
    public void updateCompany(Company company) throws CouponSystemException {
        if (!companyRepository.existsById(company.getId())) {
            throw new CouponSystemException(ErrMsg.COMPANY_NOT_EXIST);
        } else {
            /*    בדיקה האם לקוח קיים בבסיס נתונים ושליפת שורה     */
            Company fetchedCompany = companyRepository.findById(company.getId());
            fetchedCompany.setEmail(company.getEmail());
            fetchedCompany.setPassword(company.getPassword());
            try {
                companyRepository.saveAndFlush(fetchedCompany);
            } catch (Exception e) {
                System.err.println(e.getMessage());
            }
        }
    }

    @Override
    public void deleteCompany(Company company) throws CouponSystemException {
        if (!companyRepository.existsById(company.getId())) {
            throw new CouponSystemException(ErrMsg.COMPANY_NOT_EXIST);
        } else {
            try {
                couponRepository.deleteAllCompanyCouponsPurchased(company.getId());
                companyRepository.deleteById(company.getId());
            } catch (Exception e) {
                System.err.println(e.getMessage());
            }
            System.out.println("deleteCompany:  The company deleted successfully !");
        }
    }

    /*--------------------       CRUD customers ----------------------------*/
    @Override
    public void addCustomer(Customer customer) throws CouponSystemException {
        if (customerRepository.existsByEmail(customer.getEmail())) {
            throw new CouponSystemException(ErrMsg.PASSWORD_ALREADY_EXIST);
        } else {
            try {
                customerRepository.save(customer);
            } catch (Exception e) {
                System.err.println(e.getMessage());
            }
        }
    }

    @Override
    public void updateCustomer(Customer customer) throws CouponSystemException {
        if (!this.customerRepository.existsById(customer.getId())) {
            throw new CouponSystemException(ErrMsg.CUSTOMER_NOT_EXIST);
        } else {

            Customer fetchedCustomer = this.customerRepository.findById(customer.getId());
            fetchedCustomer.setEmail(customer.getEmail());
            fetchedCustomer.setPassword(customer.getPassword());
            fetchedCustomer.setFirstName(customer.getFirstName());
            fetchedCustomer.setLastName(customer.getLastName());

            try {
                customerRepository.saveAndFlush(fetchedCustomer);
            } catch (Exception e) {
                System.err.println(e.getMessage());
            }
        }
    }


    @Override
    public void deleteCustomer(Customer customer) throws CouponSystemException {
        if (customerRepository.existsById(customer.getId())) {
            try {
                /*  delete also ALL of customer's coupons purchases (ON CASCADE)*/
                customerRepository.deleteById(customer.getId());
            } catch (Exception e) {
                System.err.println(e.getMessage());
            }
        }

        /*------------------        e n d  of     ADMIN SERVICE   ---------------------------------*/
    }
}

