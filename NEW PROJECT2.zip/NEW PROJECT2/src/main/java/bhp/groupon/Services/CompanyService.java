package bhp.groupon.Services;

import bhp.groupon.beans.Category;
import bhp.groupon.beans.Company;
import bhp.groupon.beans.Coupon;
import bhp.groupon.exceptions.CouponSystemException;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public interface CompanyService {
    boolean login(String email, String password)          throws CouponSystemException;
    /* --------------------------CRUD   COMPANY--------------------------- */
    void addCoupon(int companyId,Coupon coupon)           throws CouponSystemException;
    void updateCoupon(int companyId,Coupon coupon)        throws CouponSystemException;
    void deleteCoupon(int companyId,int couponId)         throws CouponSystemException;
    /* --------------------------get ONE -------------------------------- */
    Company getCompanyDetails(int companyId)               throws CouponSystemException;
    Coupon getOneCompanyCouponByTitle(int companyId,String title) throws CouponSystemException;
    /* --------------------------get ALL -------------------------------- */
    List<Coupon> getCompanyCoupons(int companyId)          throws CouponSystemException;
    List<Coupon> getCompanyCouponsByCategory(int companyId,Category category) throws CouponSystemException;
    List<Coupon> getCompanyCouponsUnderPrice(int companyId,double price) throws CouponSystemException;


    }

