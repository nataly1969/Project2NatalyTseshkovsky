package bhp.groupon.clr.off;

import bhp.groupon.Services.AdminService;
import bhp.groupon.beans.Company;
import bhp.groupon.beans.Constants;
import bhp.groupon.security.ClientType;
import bhp.groupon.security.LoginManager;
import bhp.groupon.utils.PrintUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Order(2)
public class UseCaseAdminTestAddUpdateCompany implements CommandLineRunner {
    private AdminService adminService;
    @Autowired
    private LoginManager loginManager;
    @Override
    public void run(String... args) throws Exception {

    adminService = (AdminService) loginManager.login(Constants.ADMIN_EMAIL.getValue(), Constants.ADMIN_PASSWORD.getValue(), ClientType.ADMINISTRATOR);

    /*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
      System.out.println(">> ADMIN service 1:   get  all companies ");
      PrintUtils.printCompanies(adminService.getAllCompanies());

    /*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
      System.out.println("\n>> ADMIN service 2:   add new company Nataly@Rina ");
      Company company10 = Company.builder()
                .name("Nataly@Rina")
                .email("testNewCompany@email")
                .password(Constants.COCA_COLA_PASSWORD.getValue())
                .build();
      adminService.addCompany(company10);
      PrintUtils.printCompanies(adminService.getAllCompanies());

      /*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
        Company company2 = adminService.getOneCompany(2);
        System.out.println("\n >>ADMIN Service 3:      udateCompany 2 " + company2 + "\n");
        company2.setPassword("updated PASSWORD");
        adminService.updateCompany(company2);
        PrintUtils.printCompanies(adminService.getAllCompanies());

        /* ======================== e n d  ==========================================*/
    }
}

