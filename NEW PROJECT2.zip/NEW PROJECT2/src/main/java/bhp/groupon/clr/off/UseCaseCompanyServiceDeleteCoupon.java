package bhp.groupon.clr.off;

import bhp.groupon.Repos.CompanyRepository;
import bhp.groupon.Repos.CouponRepository;
import bhp.groupon.Repos.CustomerRepository;
import bhp.groupon.Services.CompanyService;
import bhp.groupon.beans.Constants;
import bhp.groupon.beans.Coupon;
import bhp.groupon.security.ClientType;
import bhp.groupon.security.LoginManager;
import bhp.groupon.utils.PrintUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Order(3)
public class UseCaseCompanyServiceDeleteCoupon implements CommandLineRunner {
    private  CompanyService companyService;
    @Autowired
    private LoginManager loginManager;
    @Override
    public void run(String... args) throws Exception {

    companyService = (CompanyService) loginManager.login(Constants.NIKE_EMAIL.getValue(),Constants.NIKE_PASSWORD.getValue(), ClientType.COMPANY);

    /*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
    /* Company  Service : DELETE One company Coupon */
        Coupon coupon1 = companyService.getOneCompanyCouponByTitle(1,"cola 1+1");
        System.out.println("\n >>  COMPANY Service  deleteCoupon = " + coupon1 );
        companyService.deleteCoupon(1,coupon1.getId());
        System.out.println("\n >>   table of companies after deleting of Company=1  ");
        PrintUtils.printCoupons(companyService.getCompanyCoupons(1));


        System.out.println("\n");
        /* ======================== e n d  ==========================================*/
    }
}
