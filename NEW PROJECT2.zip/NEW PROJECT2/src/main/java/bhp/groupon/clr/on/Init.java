package bhp.groupon.clr.on;

import bhp.groupon.Repos.CompanyRepository;

import bhp.groupon.Repos.CouponRepository;
import bhp.groupon.Repos.CustomerRepository;
import bhp.groupon.Services.AdminService;
import bhp.groupon.beans.*;
import bhp.groupon.security.ClientType;
import bhp.groupon.security.LoginManager;
import bhp.groupon.utils.Art;
import bhp.groupon.utils.PrintUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;

@Order(1)
@Component
public class Init implements CommandLineRunner {
    @Autowired
    private CompanyRepository companyRepository;
    @Autowired
    private CouponRepository couponRepository;
    @Autowired
    private CustomerRepository customerRepository;
    @Override
    public void run(String... args) throws Exception {

        System.out.println("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        System.out.println("@@@@=============================  I N I T I A L I Z A T I O N       =======================@@@@");
        System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        /*   INIT  C O U P O N S   */
        Coupon coupon1 = Coupon.builder()
                .category(Category.Food)
                .title("cola 1+1")
                .description("1+1")
                .startDate(Date.valueOf(LocalDate.now().minusWeeks(5)))
                .endDate(Date.valueOf(LocalDate.now().minusWeeks(2)))
                .amount(10)
                .price(5.90)
                .image("no Image ")
                .build();
        Coupon coupon2 = Coupon.builder()
                .category(Category.Food)
                .title("fanta 1+1")
                .description("1+1")
                .startDate(Date.valueOf(LocalDate.now().minusWeeks(3)))
                .endDate(Date.valueOf(LocalDate.now().minusWeeks(1)))
                .amount(10)
                .price(7.90)
                .image("no Image ")
                .build();
        Coupon coupon3 = Coupon.builder()
                .category(Category.Medicine)
                .title("Imodium 1+1")
                .description("1+1")
                .startDate(Date.valueOf(LocalDate.now().minusWeeks(1)))
                .endDate(Date.valueOf(LocalDate.now().plusWeeks(1)))
                .amount(2)
                .price(60.90)
                .image("no Image ")
                .build();
        Coupon coupon4 = Coupon.builder()
                .category(Category.Medicine)
                .title("sales drags")
                .description("30% Optalgin")
                .startDate(Date.valueOf(LocalDate.now().minusWeeks(1)))
                .endDate(Date.valueOf(LocalDate.now().plusWeeks(1)))
                .amount(10)
                .price(20.99)
                .image("no Image ")
                .build();

        Coupon coupon5 = Coupon.builder()
                .category(Category.Vacation)
                .title("Isrotel Eilat")
                .description("1+1")
                .startDate(Date.valueOf(LocalDate.now().minusWeeks(1)))
                .endDate(Date.valueOf(LocalDate.now().plusWeeks(1)))
                .amount(100)
                .price(2000.00)
                .image("no Image ")
                .build();
        Coupon coupon6 = Coupon.builder()
                .category(Category.Vacation)
                .title("Isrotel sales TLV")
                .description("1+1")
                .startDate(Date.valueOf(LocalDate.now().minusWeeks(1)))
                .endDate(Date.valueOf(LocalDate.now().plusWeeks(1)))
                .amount(100)
                .price(3000.00)
                .image("no Image ")
                .build();
        Coupon coupon7 = Coupon.builder()
                .category(Category.Vacation)
                .title("Isrotel sales Haifa")
                .description("1+1")
                .startDate(Date.valueOf(LocalDate.now().minusWeeks(1)))
                .endDate(Date.valueOf(LocalDate.now().plusWeeks(1)))
                .amount(100)
                .price(1000.00)
                .image("no Image ")
                .build();

        Coupon coupon8 = Coupon.builder()
                .category(Category.Sport)
                .title("Nike sales")
                .description("1+1 Boots")
                .startDate(Date.valueOf(LocalDate.now().minusWeeks(4)))
                .endDate(Date.valueOf(LocalDate.now().plusWeeks(2)))
                .amount(2)
                .price(800.00)
                .image("no Image ")
                .build();
        /*  ================= INIT  C O M P A N I E S =============================  */
        Company company1 = Company.builder()
                .name(Constants.COCA_COLA_NAME.getValue())
                .email(Constants.COCA_COLA_EMAIL.getValue())
                .password(Constants.COCA_COLA_PASSWORD.getValue())
                .coupons(Arrays.asList(coupon1, coupon2,coupon3))
                .build();
        Company company2 = Company.builder()
                .name(Constants.SUPER_PHARM_NAME.getValue())
                .email(Constants.SUPER_PHARM_EMAIL.getValue())
                .password(Constants.SUPER_PHARM_PASSWORD.getValue())
                .coupons(Arrays.asList(coupon4))
                .build();
        Company company3 = Company.builder()
                .name(Constants.NIKE_NAME.getValue())
                .email(Constants.NIKE_EMAIL.getValue())
                .password(Constants.NIKE_PASSWORD.getValue())
                .coupons(Arrays.asList(coupon8))
                .build();
        Company company4 = Company.builder()
                .name(Constants.ISROTEL_NAME.getValue())
                .email(Constants.ISROTEL_EMAIL.getValue())
                .password(Constants.ISROTEL_PASSWORD.getValue())
                .coupons(Arrays.asList(coupon5, coupon6,coupon7))
                .build();
        Company company5 = Company.builder()
                .name(Constants.MAX_BRENNER_NAME.getValue())
                .email(Constants.MAX_BRENNER_EMAIL.getValue())
                .password(Constants.MAX_BRENNER_PASSWORD.getValue())
                .build();

        coupon1.setCompany(company1);
        coupon2.setCompany(company1);
        coupon3.setCompany(company1);
        coupon4.setCompany(company2);
        coupon5.setCompany(company4);
        coupon6.setCompany(company4);
        coupon7.setCompany(company4);
        coupon8.setCompany(company3);

        for (Company company : Arrays.asList(company1, company2, company3, company4, company5)) {
            companyRepository.save(company);}

        /*  ================= INIT  C U S T O M E R S   =============================  */
        Customer customer1 = Customer.builder().firstName("Artur").lastName("Kayakman")
                .email(Constants.CUSTOMER1_EMAIL.getValue())
                .password(Constants.CUSTOMER1_PASSWORD.getValue())
                .coupons(Arrays.asList(coupon1, coupon2,coupon3,coupon8))
                 .build();
        Customer customer2 = Customer.builder().firstName("Rollo").lastName("Dinnerov")
                .email(Constants.CUSTOMER2_EMAIL.getValue())
                .password(Constants.CUSTOMER2_PASSWORD.getValue())
                .coupons(Arrays.asList(coupon3, coupon4,coupon5))
                .build();
        Customer  customer3 = Customer.builder().firstName("Eli").lastName("Sportsmen")
                .email(Constants.CUSTOMER3_EMAIL.getValue())
                .password(Constants.CUSTOMER3_PASSWORD.getValue())
                .coupons(Arrays.asList(coupon1, coupon2,coupon3,coupon7))

                .build();
        Customer  customer4 = Customer.builder().firstName("Geula").lastName("Sportsmen")
                .email(Constants.CUSTOMER4_EMAIL.getValue())
                .password(Constants.CUSTOMER4_PASSWORD.getValue())
                .coupons(Arrays.asList(coupon5, coupon6,coupon7,coupon8))
                .build();

        Customer customer5 = Customer.builder().firstName("Max").lastName("Chokolatier")
                .email(Constants.CUSTOMER5_EMAIL.getValue())
                .password(Constants.CUSTOMER5_PASSWORD.getValue())
                 .build();
        for (Customer customer: Arrays.asList(customer1,customer2,customer3,customer4,customer5)) {
           customerRepository.save(customer);}


        System.out.println(Art.TABLE_COMPANY);
        PrintUtils.printCompanies(companyRepository.findAll());
        System.out.println(Art.TABLE_COUPONS);
        PrintUtils.printCoupons(couponRepository.findAll());
        System.out.println(Art.TABLE_CUSTOMERS);
        PrintUtils.printCustomers(customerRepository.findAll());
        System.out.println(Art.TABLE_UNDER);
    }
}
