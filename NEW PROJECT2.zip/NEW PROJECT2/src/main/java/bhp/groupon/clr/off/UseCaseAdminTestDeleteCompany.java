package bhp.groupon.clr.off;

import bhp.groupon.Services.AdminService;
import bhp.groupon.beans.Company;
import bhp.groupon.beans.Constants;
import bhp.groupon.security.ClientType;
import bhp.groupon.security.LoginManager;
import bhp.groupon.utils.PrintUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Order(2)
public class UseCaseAdminTestDeleteCompany implements CommandLineRunner {
    private AdminService adminService;
    @Autowired
    private LoginManager loginManager;

    @Override
    public void run(String... args) throws Exception {

    System.out.println("Constants.ADMIN_EMAIL.getValue()=" + Constants.ADMIN_EMAIL.getValue() );
    adminService = (AdminService) loginManager.login(Constants.ADMIN_EMAIL.getValue(),Constants.ADMIN_PASSWORD.getValue(), ClientType.ADMINISTRATOR);

 /*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
 /*    =============admin service :  deleteCompany  = 1    ===========*/
        Company company1 = adminService.getOneCompany(1);
        System.out.println("\n >>    adminService.deleteCompany = 1  ");
        PrintUtils.printCompanies(adminService.getAllCompanies());
        adminService.deleteCompany(company1);
        System.out.println("\n >>    after deleting of Company=1  ");
        PrintUtils.printCompanies(adminService.getAllCompanies());
        System.out.println("===============   end of delete company test=============");
        /* ======================== e n d  ==========================================*/
    }
}

