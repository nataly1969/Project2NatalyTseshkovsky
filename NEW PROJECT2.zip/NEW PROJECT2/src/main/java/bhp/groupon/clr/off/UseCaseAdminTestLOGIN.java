package bhp.groupon.clr.off;

import bhp.groupon.Services.AdminService;
import bhp.groupon.beans.Company;
import bhp.groupon.beans.Constants;
import bhp.groupon.security.ClientType;
import bhp.groupon.security.LoginManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Order(2)
public class UseCaseAdminTestLOGIN implements CommandLineRunner {
    @Autowired
    private AdminService adminService;
    @Autowired
    private LoginManager loginManager;

    @Override
    public void run(String... args) throws Exception {

//       LoginManager loginManager = LoginManager.getInstance();
        System.out.println("Constants.ADMIN_EMAIL.getValue()=" + Constants.ADMIN_EMAIL.getValue());
        adminService = (AdminService) loginManager.login(Constants.ADMIN_EMAIL.getValue(), Constants.ADMIN_PASSWORD.getValue(), ClientType.ADMINISTRATOR);
//
        /*    admin service 1  :   get  all companies :*/
        System.out.println("admin service 1  :   get  all companies ");
        adminService.getAllCompanies().forEach(System.out::println);

        /*    admin service 4  :  GET ONE   company 2  :*/
        Company company2 = adminService.getOneCompany(2);


        /* ======================== e n d  ==========================================*/
    }
}

