package bhp.groupon.clr.off;

import bhp.groupon.Services.CustomerService;
import bhp.groupon.beans.Category;
import bhp.groupon.beans.Constants;
import bhp.groupon.beans.Customer;
import bhp.groupon.security.ClientType;
import bhp.groupon.security.LoginManager;
import bhp.groupon.utils.PrintUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Order(8)
public class UseCaseCustomerFacadeGetCouponsBy implements CommandLineRunner {
    private CustomerService customerService;
    @Autowired
    private LoginManager loginManager;
    @Override
    public void run(String... args) throws Exception {

     customerService = (CustomerService)loginManager.login(Constants.CUSTOMER3_EMAIL.getValue(),Constants.CUSTOMER3_PASSWORD.getValue(), ClientType.CUSTOMER);

     /*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
        System.out.println("\n CUSTOMER service >>     getCustomerDetails = 3 :");
        PrintUtils.printCustomer(customerService.getCustomersDetails(3));

     /*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
        System.out.println("\n CUSTOMER service  >>   getCustomerCoupons for customer=3 ");
        PrintUtils.printCoupons(customerService.getCustomerCoupons(3));

     /*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
        System.out.println("\n CUSTOMER service  >>   getCustomerCouponsByCategory for customer=4 by Category = VACATIONS");
        PrintUtils.printCoupons(customerService.getCustomerCouponsByCategory(4,Category.Vacation));

     /*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
        System.out.println("\n CUSTOMER service  >>   getCustomerCouponsUnderPrice for customer=3 by price < 1000");//        customerService.getCustomerCouponsMaxPrice(3,1000).forEach(System.out::println);
        PrintUtils.printCoupons(customerService.getCustomerCouponsMaxPrice(3,1000));

     /* ======================== e n d  ==========================================*/
    }
}