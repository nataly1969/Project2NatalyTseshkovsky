package bhp.groupon.clr.off;

import bhp.groupon.Services.CompanyService;
import bhp.groupon.beans.Category;
import bhp.groupon.beans.Company;
import bhp.groupon.beans.Constants;
import bhp.groupon.beans.Coupon;
import bhp.groupon.security.ClientType;
import bhp.groupon.security.LoginManager;
import bhp.groupon.utils.PrintUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
@Component
@Order(3)
public class UseCaseCompanyServiceGetCouponsBy implements CommandLineRunner {
    private CompanyService companyService;
    @Autowired
    private LoginManager loginManager;
    @Override
    public void run(String... args) throws Exception {

    Company company1;
    Coupon coupon1;

    companyService = (CompanyService) loginManager.login(Constants.COCA_COLA_EMAIL.getValue(), Constants.COCA_COLA_PASSWORD.getValue(), ClientType.COMPANY);

    /*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
    /*  Get company details  */
        System.out.println("\n >>   COMPANY Service   getCompanyDetails   =  1 \n");
        PrintUtils.printCompany(company1 = companyService.getCompanyDetails(1));

    /*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
    /*  Get One company Coupon by Title  */
        System.out.println("\n >>   COMPNAY Service    getOneCompanyCouponByTitle = cola 1+1   ");
        PrintUtils.printCoupon(coupon1 = companyService.getOneCompanyCouponByTitle(1, "cola 1+1"));
    /*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
    /*  Get company Coupons by Category  */
        System.out.println("\n >>   COMPNAY Service    getCompanyCouponsByCategory = Food ");
        PrintUtils.printCoupons(companyService.getCompanyCouponsByCategory(1, Category.Food));

    /*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
    /*   Get company Coupons by Price Less Then 100  */
        System.out.println("\n >>   COMPANY Service    getCompanyCouponsUnderPrice < 100 ");
        PrintUtils.printCoupons(companyService.getCompanyCouponsUnderPrice(1, 100));

        System.out.println("\n");
    /* ======================== e n d  ==========================================*/
    }
}
