package bhp.groupon.clr.off;

import bhp.groupon.Services.AdminService;
import bhp.groupon.beans.Constants;
import bhp.groupon.beans.Customer;
import bhp.groupon.security.ClientType;
import bhp.groupon.security.LoginManager;
import bhp.groupon.utils.PrintUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.Arrays;

@Component
@Order(5)
public class UseCaseAdminTestAddUpdateCustomer implements CommandLineRunner {
    private AdminService adminService;
    @Autowired
    private LoginManager loginManager;
    @Override
    public void run(String... args) throws Exception {

    System.out.println("Constants.ADMIN_EMAIL.getValue()=" + Constants.ADMIN_EMAIL.getValue() );
    adminService = (AdminService) loginManager.login(Constants.ADMIN_EMAIL.getValue(),Constants.ADMIN_PASSWORD.getValue(), ClientType.ADMINISTRATOR);

    /*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
    /*      Admin service  AddCustomer       */
        Customer customer6 = Customer.builder().firstName("Nataly").lastName("Kayakman")
                .email("natalytest@gmail.com")
                .password(Constants.CUSTOMER1_PASSWORD.getValue())
                .build();
        System.out.println(" >>    ADMIN Service   addCustomer = " + customer6);
         adminService.addCustomer(customer6);
         PrintUtils.printCustomers(adminService.getAllCustomers());

        /*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
        /*      Admin service  updateCustomer       */
        Customer customer2 = adminService.getOneCustomer(2);
        System.out.println(" >>    ADMIN Service   updateCustomer = 2 >>(UPDATED Password)\n" + customer2);
        customer2.setPassword("UPDATED Password");
        adminService.updateCustomer(customer2);
        PrintUtils.printCustomers(adminService.getAllCustomers());

        /* ======================== e n d  ==========================================*/
    }
}

