package bhp.groupon.clr.off;

import bhp.groupon.Services.AdminService;
import bhp.groupon.beans.*;
import bhp.groupon.security.ClientType;
import bhp.groupon.security.LoginManager;
import bhp.groupon.utils.PrintUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
    @Order(5)
    public class UseCaseAdminTestDeleteCustomer implements CommandLineRunner {
        private AdminService adminService;
        @Autowired
        private LoginManager loginManager;
        @Override
        public void run(String... args) throws Exception {

    // not needed !  LoginManager loginManager = LoginManager.getInstance();
            System.out.println("Constants.ADMIN_EMAIL.getValue()=" + Constants.ADMIN_EMAIL.getValue() );
           adminService = (AdminService) loginManager.login(Constants.ADMIN_EMAIL.getValue(),Constants.ADMIN_PASSWORD.getValue(), ClientType.ADMINISTRATOR);

    /*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
     /*    ADMIN Service 6  :  DELETE   customer 1  ===========*/
            Customer customer1 = adminService.getOneCustomer(1);
            System.out.println("\n >>  ADMIN Service  deleteCustomer = 1 " + customer1);
            System.out.println(" >>   table of customers BEFORE delete  customer=1 :   ");
            PrintUtils.printCustomers(adminService.getAllCustomers());
            adminService.deleteCustomer(customer1);
            System.out.println(" >>   table of customers AFTER delete  customer=1 :   ");
            PrintUtils.printCustomers(adminService.getAllCustomers());


            System.out.println("\n");
      /* ========================     e n d     ==========================================*/
        }
    }

