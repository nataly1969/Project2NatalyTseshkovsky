package bhp.groupon.clr.off;

import bhp.groupon.Services.CustomerService;
import bhp.groupon.beans.Constants;
import bhp.groupon.beans.Coupon;
import bhp.groupon.beans.Customer;
import bhp.groupon.security.ClientType;
import bhp.groupon.security.LoginManager;
import bhp.groupon.utils.Art;
import bhp.groupon.utils.PrintUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Order(5)
public class UseCaseCustomerFacadePourchaseCoupon implements CommandLineRunner {
    private CustomerService customerService;
    @Autowired
    private LoginManager loginManager;
    @Override
    public void run(String... args) throws Exception {

     customerService = (CustomerService)loginManager.login(Constants.CUSTOMER3_EMAIL.getValue(),Constants.CUSTOMER3_PASSWORD.getValue(), ClientType.CUSTOMER);

     /*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
     /*    CUSTOMER  service 1  :   getCustomer Details   :*/
        System.out.println(Art.SCHTRUDEL);
        System.out.println("CUSTOMER service >>     getCustomerDetails = 3 : \n");
        Customer customer3 = customerService.getCustomersDetails(3);
        System.out.println( customer3 + "\n");

     /*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
     /*    CUSTOMER  service 5  :   Purchase Coupon  = 5  of company 3    :*/
        System.out.println(Art.SCHTRUDEL);
        Coupon coupon5 = customerService.getOneCompanyCouponByTitle(3,"Nike sales");
        System.out.println("CUSTOMER service >>     purchaseCoupon = 5 : " + coupon5 );
        System.out.println("\n  BEFORE purchasing (cola 1+1) by " + customer3 );
        PrintUtils.printCoupons(customerService.getCustomerCoupons(3));
        customerService.purchaseCoupon(3,coupon5);
//        customerService.purchaseCoupon(2,coupon5);
        System.out.println("\n  AFTER purchasing (cola 1+1) by " + customer3 +  "\n");
        PrintUtils.printCoupons(customerService.getCustomerCoupons(3));



        System.out.println("\n");
 /* ======================== e n d  ==========================================*/
    }
}
