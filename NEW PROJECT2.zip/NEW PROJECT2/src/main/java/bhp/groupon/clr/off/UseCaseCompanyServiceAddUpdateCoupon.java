package bhp.groupon.clr.off;

import bhp.groupon.Repos.CompanyRepository;
import bhp.groupon.Repos.CouponRepository;
import bhp.groupon.Repos.CustomerRepository;
import bhp.groupon.Services.CompanyService;
import bhp.groupon.beans.Category;
import bhp.groupon.beans.Constants;
import bhp.groupon.beans.Coupon;
import bhp.groupon.security.ClientType;
import bhp.groupon.security.LoginManager;
import bhp.groupon.utils.PrintUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.sql.Date;
import java.time.LocalDate;

@Component
@Order(3)
public class UseCaseCompanyServiceAddUpdateCoupon implements CommandLineRunner {
    private  CompanyService companyService;
    @Autowired
    private LoginManager loginManager;
    @Override
    public void run(String... args) throws Exception {

    companyService = (CompanyService) loginManager.login(Constants.NIKE_EMAIL.getValue(),Constants.NIKE_PASSWORD.getValue(), ClientType.COMPANY);

  /*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
  /*   CompanyService  AddCoupon  */
        Coupon coupon9 = Coupon.builder()
                .category(Category.Food)
                .title("TEST_ADD_COUPON")
                .description("1+1")
                .startDate(Date.valueOf(LocalDate.now().minusWeeks(5)))
                .endDate(Date.valueOf(LocalDate.now().minusWeeks(2)))
                .amount(10)
                .price(15.90)
                .image("no Image ")
                .build();

        System.out.println("\n >>   COMPANY Service   BEFORE addCoupon = TEST_ADD_COUPON:" );
        PrintUtils.printCoupons(companyService.getCompanyCoupons(1));
        companyService .addCoupon(1, coupon9);
        System.out.println("\n >>                      AFTER addCoupon TEST_ADD_COUPON:");
        PrintUtils.printCoupons(companyService.getCompanyCoupons(1));

     /*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
     /* CompanyService  Update Coupon   */
        Coupon coupon1 = companyService.getOneCompanyCouponByTitle(1,"cola 1+1");
        System.out.println("\n >>  COMPANY Service : updateCoupon AMOUNT AND DESCRIPTION" + coupon1);
        coupon1.setAmount(2000);
        coupon1.setDescription("UPDATED COUPON");
        companyService.updateCoupon(1,coupon1);
        System.out.println("\n >>  After updating of Description and Amount:");
        PrintUtils.printCoupons(companyService.getCompanyCoupons(1));
        System.out.println("\n");


        /* ======================== e n d  ==========================================*/
    }
}
