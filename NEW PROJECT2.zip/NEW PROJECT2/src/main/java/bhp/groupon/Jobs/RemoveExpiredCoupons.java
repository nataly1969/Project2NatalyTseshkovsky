package bhp.groupon.Jobs;

import bhp.groupon.Repos.CouponRepository;
import bhp.groupon.Repos.CustomerRepository;
import bhp.groupon.beans.Coupon;
import bhp.groupon.beans.Customer;
import bhp.groupon.utils.Art;
import bhp.groupon.utils.PrintUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.List;

@Component
public class RemoveExpiredCoupons {

    @Autowired
    private CouponRepository couponRepository;
    @Autowired
    private CustomerRepository customerRepository;
    @Scheduled(fixedRate = 1000 * 60 * 60 * 24)

    public void run() throws Exception{

        Thread.sleep( 2000);
        System.out.println(Art.START_JOB);
        List<Coupon> coupons = null;
        coupons = couponRepository.getAllCouponsExpiredDate();
        System.out.println(" Amount of EXPIRED coupons =" + coupons.size());

        for (Coupon coupon : coupons) {
               couponRepository.deletePurchasesOfCoupon(coupon.getId());
               couponRepository.saveAndFlush(coupon);
            System.out.println(">> expired coupon = " + coupon);
        }
        couponRepository.deleteAllCouponsExpiredDate();

        System.out.println(Art.COUPONS_AFTER);
        PrintUtils.printCoupons(couponRepository.findAll());
        System.out.println(Art.TABLE_UNDER + "\n" + Art.END_JOB + "\n");


    }
    /*  -----------------          END    CLASS           ------------------  */
}






//            for (Customer customer : customers) {
//                System.out.println("  current CUSTOMER FOR DELETED COUPON :" + customer);
//                customer.getCoupons().remove(coupon);
//                customerRepository.saveAndFlush(customer);
//            }
//                           (   couponRepository.deleteById(coupon.getId());
//                              couponRepository.saveAndFlush(coupon);  )

